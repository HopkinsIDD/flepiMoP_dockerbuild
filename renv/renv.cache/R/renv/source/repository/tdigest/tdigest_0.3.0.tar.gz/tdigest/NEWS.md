0.3.0
* ALTREP-aware
* `length()` and `[` implemented for `tdigest` objects

0.2.0
* Added input validity checks
* Added `quantile()` function S3 implementation for `tdigest` objects
* Added examples
* Added more tests

0.1.0 
* Initial release
