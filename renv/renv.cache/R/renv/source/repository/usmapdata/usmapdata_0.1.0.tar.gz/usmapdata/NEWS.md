# usmapdata 0.1.0

* First release

### Main features

* Contains the `us_map` function and associated data extracted from the `usmap` package
* Will allow future removal of data from `usmap` package so file size can be reduced greatly.
