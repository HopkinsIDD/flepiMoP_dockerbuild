library(testthat)
library(usmapdata)

test_check("usmapdata")
