<!---
Each source file contains a preamble explaining the license situation
for that file, which takes priority over this file.  With the
exception of some code pulled in from other repositories (such as
µnit, an MIT-licensed project which is used for testing), the code is
public domain, released using the CC0 1.0 Universal dedication.
-->

The files in this directory are vendored from portable-snippets
git changeset f596f8b0a4b8a6ea1166c2361a5cb7e6f802c5ea.
