#' @docType package
#' @keywords internal
#' @aliases gt-package
"_PACKAGE"
