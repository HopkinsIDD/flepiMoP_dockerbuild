##
## Check arguments for length and type
##

context("reg-arg_checks")
