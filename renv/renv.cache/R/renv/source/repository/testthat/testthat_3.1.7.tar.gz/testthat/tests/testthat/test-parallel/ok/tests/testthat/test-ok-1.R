test_that("this is good", {
  expect_equal(2 * 2, 4)
})
