# reporter basics works

    'reporters/tests.R:12:3' [failure] Failure:1. FALSE is not TRUE
    'reporters/tests.R:17:3' [failure] Failure:2a. FALSE is not TRUE
    'reporters/tests.R:23:3' [error] Error:1. Error in `eval(code, test_env)`: stop
    'reporters/tests.R:31:3' [error] errors get tracebacks. Error in `h()`: !
    'reporters/tests.R:37:3' [skip] explicit skips are reported. Reason: skip
    'reporters/tests.R:40:1' [skip] empty tests are implicitly skipped. Reason: empty test
    'reporters/tests.R:49:3' [warning] warnings get backtraces. def
    'reporters/tests.R:45:1' [skip] warnings get backtraces. Reason: empty test

